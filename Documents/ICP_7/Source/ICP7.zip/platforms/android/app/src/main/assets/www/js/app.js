// Ionic Starter App

// angular.module is a global place for creating, registering and retrieving Angular modules
// 'starter' is the name of this angular module example (also set in a <body> attribute in index.html)
// the 2nd parameter is an array of 'requires'
// Initialize Firebase

var starter=angular.module("starter", ["ionic","ngCordova","firebase"]);
starter.config(function($stateProvider, $urlRouterProvider) {
  $stateProvider
    .state("firebase", {
      url: "/firebase",
      templateUrl: "../Pages/Login.html",
      controller: "FirebaseController",
      cache: false
    })
    .state("secure", {
      url: "/secure",
      templateUrl: "../Pages/CameraActivity.html",
      controller: "SecureController"
    });
  $urlRouterProvider.otherwise('/firebase');
});
starter.run(function($ionicPlatform) {

  $ionicPlatform.ready(function() {
    // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
    // for form inputs).
    // The reason we default this to hidden is that native apps don't usually show an accessory bar, at
    // least on iOS. It's a dead giveaway that an app is using a Web View. However, it's sometimes
    // useful especially with forms, though we would prefer giving the user a little more room
    // to interact with the app.
    if (window.cordova && window.Keyboard) {
      window.Keyboard.hideKeyboardAccessoryBar(true);
    }

    if (window.StatusBar) {
      // Set the statusbar to use the default style, tweak this to
      // remove the status bar on iOS or change it to use white instead of dark colors.
      StatusBar.styleDefault();
    }
  });
})
starter.controller("FirebaseController", function($scope,$state, $firebaseAuth) {

  var fbAuth = $firebaseAuth();

  $scope.login = function(username, password) {
    if(username==null || username== "" || password==null || password==""){
      alert('Enter username and Password');
      return;
    }
    fbAuth.$signInWithEmailAndPassword(username,password).then(function(authData) {
      $state.go("secure");
    }).catch(function(error) {
      alert('Enter valid username and Password');
    });
  }

  $scope.register = function(username, password) {
    if(username==null || username== "" || password==null || password==""){
      alert('Enter username and Password');
      return;
    }
    fbAuth.$createUserWithEmailAndPassword(username,password).then(function(userData) {
      return fbAuth.$signInWithEmailAndPassword(username,
        password);
    }).then(function(authData) {
      $state.go("secure");
    }).catch(function(error) {
      console.error("ERROR: " + error);
      alert('Enter valid username and Password');
    });
  }
  $scope.google=function(){
  var provider= new firebase.auth.GoogleAuthProvider();
  provider.addScope('https://www.googleapis.com/auth/contacts.readonly');
    firebase.auth().signInWithPopup(provider).then(function (result) {
    var token = result.credential.accessToken;
    // The signed-in user info.
    var user = result.user;
      $state.go("secure");
  }).catch(function(error) {
    // Handle Errors here.
    var errorCode = error.code;
    var errorMessage = error.message;
    // The email of the user's account used.
    var email = error.email;
    // The firebase.auth.AuthCredential type that was used.
    var credential = error.credential;
    alert(errorMessage);
    // ...
  });
  }

});
starter.controller("SecureController", function($scope, $ionicHistory, $firebaseObject, $firebaseArray, $firebaseAuth, $cordovaCamera,$state) {

  $ionicHistory.clearHistory();  //for clearing user login history

  $scope.images = [];
  $scope.fb = $firebaseAuth();
  var fbAuth = $scope.fb.$getAuth();
  var ref = firebase.database().ref();
  var obj = $firebaseObject(ref);
  var syncArray;
  if(fbAuth) {
    var userReference = ref.child("users/" + fbAuth.uid);   //capture the user reference in data structure ,it navigates to specific user page in freebase
    syncArray = $firebaseArray(userReference.child("images"));  //binding specific node in firebase to an array object in angularjs;
    $scope.images = syncArray;
  } else {
    $state.go("firebase");  //directs to firebase page
  }
$scope.logout=function(){
  firebase.auth().signOut().then(function() {
    // Sign-out successful.
    $state.go("firebase");
  }, function(error) {
    // An error happened.
  });
}
  $scope.upload = function() {
    var options = {
      quality : 75,
      destinationType : Camera.DestinationType.DATA_URL,
      sourceType : Camera.PictureSourceType.CAMERA,
      allowEdit : true,
      encodingType: Camera.EncodingType.JPEG,
      popoverOptions: CameraPopoverOptions,
      targetWidth: 500,
      targetHeight: 500,
      saveToPhotoAlbum: false
    };
    $cordovaCamera.getPicture(options).then(function(imageData) {
      syncArray.$add({image: imageData}).then(function() {
        alert("Image has been uploaded");
      },function(error) {
        alert(error);
      });
    }, function(error) {
      alert(error);
    });
  }

});
