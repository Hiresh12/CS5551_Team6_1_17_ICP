import { Component } from '@angular/core';
import { NavController,AlertController } from 'ionic-angular';

@Component({
  selector: 'page-Register',
  templateUrl: 'Register.html'
})
export class RegisterPage {
  public firstName:any;
  public lasttName:any;
  public userName:any;
  public tpassword:any;
  public conpassword:any;
  constructor(public navCtrl: NavController,public Alertctrl:AlertController) {

  }
  showAlert(a) {
    let alert = this.Alertctrl.create({
      title: 'Alert!',
      subTitle: a,
      buttons: ['Ok']
    });
    alert.present(alert);

  }
  Register(){
    var missingValues = "";
    if (this.firstName == null || this.firstName == "") {
      missingValues = missingValues + "First Name,";
    }
    if (this.lasttName == null || this.lasttName == "") {
      missingValues = missingValues + "Last Name,";
    }
    if (this.userName == null || this.userName == "") {
      missingValues = missingValues + "User Name,";
    }
    if (this.tpassword == null || this.tpassword == "") {
      missingValues = missingValues + "Password,";
    }
    if (this.conpassword == null || this.conpassword == "") {
      missingValues = missingValues + "Confirm Password,";
    }
    if (missingValues != null && missingValues != "") {
      this.showAlert("Please Enter :" + missingValues.substr(0,missingValues.length-1));
    }
    else
    {
      if(this.tpassword!=this.conpassword)
      {
        this.showAlert("Password and Confirm Password should be same");
      }
      else {
        this.showAlert('User Registered Successfully');
      }
    }
  }

}
