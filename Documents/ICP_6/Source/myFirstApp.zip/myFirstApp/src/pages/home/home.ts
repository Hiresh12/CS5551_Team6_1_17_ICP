import { Component } from '@angular/core';
import { NavController,AlertController } from 'ionic-angular';
import {RegisterPage} from "../Register/Register";

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage{
public  Uname:any;
public Password:any;
  constructor(public navCtrl: NavController,public Alertctrl:AlertController) {

  }
  showAlert(a) {
    let alert = this.Alertctrl.create({
      title: 'Alert!',
      subTitle: a,
      buttons: ['Ok']
    });
    alert.present(alert);

  }
  login()
  {
    if(this.Uname==null||this.Uname==""||this.Password==null||this.Password=="")
    {
      this.showAlert('Enter username and password');
    }
    else if(this.Uname=="Hiresh" && this.Password=="Hiresh")
    {
      this.showAlert('login Successfully');
    }
    else {
      this.showAlert('Incorrect username and password');
    }
  }
  regTo() {
    this.navCtrl.push(RegisterPage);
  }

}
